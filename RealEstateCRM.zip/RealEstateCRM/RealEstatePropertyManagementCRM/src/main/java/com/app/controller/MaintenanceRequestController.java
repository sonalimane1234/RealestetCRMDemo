package com.app.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.Enum.MaintenanceStatus;
import com.app.entities.MaintenanceRequest;
import com.app.repositiory.MaintenanceRequestRepository;

@RestController // Marks this class as a REST controller for handling HTTP requests and returning JSON responses.
@RequestMapping("/api/maintenance") // Base URL for all endpoints related to maintenance requests.
public class MaintenanceRequestController {

    // Injects the repository to interact with the database for MaintenanceRequest operations.
    @Autowired
    private MaintenanceRequestRepository maintenanceRequestRepository;

    /**
     * Endpoint to create a new maintenance request.
     * URL: POST /api/maintenance
     * @param maintenanceRequest The maintenance request details sent in the request body.
     * @return The created MaintenanceRequest object with default status as PENDING and current date.
     */
    @PostMapping
    public ResponseEntity<MaintenanceRequest> createRequest(@Valid @RequestBody MaintenanceRequest maintenanceRequest) {
        // Set the initial status and reported date for the new request.
        maintenanceRequest.setStatus(MaintenanceStatus.PENDING);
        maintenanceRequest.setReportedDate(LocalDate.now());
        // Save the request to the database and return the created object.
        return ResponseEntity.ok(maintenanceRequestRepository.save(maintenanceRequest));
    }

    /**
     * Endpoint to fetch all maintenance requests.
     * URL: GET /api/maintenance
     * @return A list of all maintenance requests from the database.
     */
    @GetMapping
    public ResponseEntity<List<MaintenanceRequest>> getAllRequests() {
        return ResponseEntity.ok(maintenanceRequestRepository.findAll());
    }

    /**
     * Endpoint to fetch a specific maintenance request by ID.
     * URL: GET /api/maintenance/{id}
     * @param id The ID of the maintenance request to fetch.
     * @return The maintenance request object if found, or a 404 status if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<MaintenanceRequest> getRequestById(@PathVariable Long id) {
        Optional<MaintenanceRequest> request = maintenanceRequestRepository.findById(id);
        return request.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    /**
     * Endpoint to update an existing maintenance request.
     * URL: PUT /api/maintenance/{id}
     * @param id The ID of the maintenance request to update.
     * @param updatedRequest The updated details of the maintenance request.
     * @return The updated maintenance request if successful, or a 404 status if not found.
     */
    @PutMapping("/{id}")
    public ResponseEntity<MaintenanceRequest> updateRequest(@PathVariable Long id,
            @Valid @RequestBody MaintenanceRequest updatedRequest) {
        return maintenanceRequestRepository.findById(id).map(existingRequest -> {
            // Update the fields of the existing request.
            existingRequest.setIssueDescription(updatedRequest.getIssueDescription());
            existingRequest.setStatus(updatedRequest.getStatus());
            existingRequest.setResolvedDate(updatedRequest.getResolvedDate());
            // Save the updated request to the database.
            return ResponseEntity.ok(maintenanceRequestRepository.save(existingRequest));
        }).orElse(ResponseEntity.notFound().build());
    }

    /**
     * Endpoint to delete a maintenance request by ID.
     * URL: DELETE /api/maintenance/{id}
     * @param id The ID of the maintenance request to delete.
     * @return A 204 status if deletion is successful, or a 404 status if not found.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRequest(@PathVariable Long id) {
        if (maintenanceRequestRepository.existsById(id)) {
            // Delete the maintenance request if it exists in the database.
            maintenanceRequestRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        // Return a 404 status if the request ID does not exist.
        return ResponseEntity.notFound().build();
    }
}
