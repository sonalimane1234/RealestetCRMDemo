package com.app.Enum;

public enum Status {
	AVAILABLE ,
	Available,
    OCCUPIED,
    UNDER_MAINTENANCE
}
