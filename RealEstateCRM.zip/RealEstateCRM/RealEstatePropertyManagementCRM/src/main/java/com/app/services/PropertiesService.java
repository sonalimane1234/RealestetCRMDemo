package com.app.services;

import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;

import com.app.entities.Properties;
import com.app.repositiory.PropertiesRepository;

/**
 * Service class for managing properties.
 * Provides methods for CRUD operations and additional business logic related to properties.
 */
@Service
public class PropertiesService {

    private final PropertiesRepository propertiesRepository;

    /**
     * Constructor-based dependency injection for the PropertiesRepository.
     *
     * @param propertiesRepository the repository used to interact with the database.
     */
    public PropertiesService(PropertiesRepository propertiesRepository) {
        this.propertiesRepository = propertiesRepository;
    }

    /**
     * Adds a new property to the database.
     *
     * @param property the property entity to save.
     * @return the saved property entity.
     */
    public Properties addProperty(Properties property) {
        return propertiesRepository.save(property);
    }

    /**
     * Updates an existing property in the database.
     *
     * @param id the ID of the property to update.
     * @param updatedProperty the new property details to update.
     * @return the updated property entity.
     * @throws EntityNotFoundException if the property with the given ID is not found.
     */
    public Properties updateProperty(Long id, Properties updatedProperty) {
        // Fetch the existing property by ID, or throw an exception if not found.
        Properties existingProperty = propertiesRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Property not found with id " + id));

        // Update the fields of the existing property.
        existingProperty.setName(updatedProperty.getName());
        existingProperty.setLocation(updatedProperty.getLocation());
        existingProperty.setStatus(updatedProperty.getStatus());

        // Save and return the updated property.
        return propertiesRepository.save(existingProperty);
    }

    /**
     * Deletes a property from the database.
     *
     * @param id the ID of the property to delete.
     * @throws EntityNotFoundException if the property with the given ID is not found.
     */
    public void deleteProperty(Long id) {
        if (!propertiesRepository.existsById(id)) {
            throw new EntityNotFoundException("Property not found with id " + id);
        }
        propertiesRepository.deleteById(id);
    }

    /**
     * Retrieves a property by its ID.
     *
     * @param id the ID of the property to retrieve.
     * @return the property entity.
     * @throws EntityNotFoundException if the property with the given ID is not found.
     */
    public Properties getPropertyById(Long id) {
        return propertiesRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Property not found with id " + id));
    }

    /**
     * Retrieves all properties from the database.
     *
     * @return a list of all property entities.
     */
    public List<Properties> getAllProperties() {
        return propertiesRepository.findAll();
    }

    /**
     * Retrieves all properties managed by a specific manager.
     *
     * @param managerId the ID of the manager whose properties to fetch.
     * @return a list of properties managed by the specified manager.
     */
    public List<Properties> getPropertiesByManager(Long managerId) {
        return propertiesRepository.findByManagerId(managerId);
    }
}
