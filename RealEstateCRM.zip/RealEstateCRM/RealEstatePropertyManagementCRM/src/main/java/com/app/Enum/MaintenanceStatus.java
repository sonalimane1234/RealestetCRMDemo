package com.app.Enum;

public enum MaintenanceStatus {
	PENDING, IN_PROGRESS, COMPLETED
}
