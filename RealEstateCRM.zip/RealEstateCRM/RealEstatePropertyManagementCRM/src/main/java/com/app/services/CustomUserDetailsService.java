package com.app.services;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.entities.User;
import com.app.repositiory.UserRepository;

/**
 * Custom implementation of Spring Security's UserDetailsService interface.
 * Used for retrieving user details during authentication.
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    /**
     * Constructor-based dependency injection for UserRepository.
     *
     * @param userRepository the repository to interact with the User database.
     */
    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /**
     * Loads a user's details from the database using their email.
     *
     * @param email the email of the user to retrieve.
     * @return UserDetails object containing the user's credentials and roles.
     * @throws UsernameNotFoundException if no user is found with the given email.
     */
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Fetch the user from the repository using their email.
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Return a Spring Security UserDetails object with the user's details.
        return org.springframework.security.core.userdetails.User
                .withUsername(user.getEmail()) // Set the username as the user's email.
                .password(user.getPassword())  // Set the hashed password.
                .roles(user.getRole().name())  // Set the roles as defined in the User entity.
                .build();
    }
}
