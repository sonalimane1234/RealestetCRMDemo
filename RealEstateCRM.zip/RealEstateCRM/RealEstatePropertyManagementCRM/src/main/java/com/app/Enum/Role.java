package com.app.Enum;

public enum Role {

    ADMIN, MANAGER, TENANT,PROPERTY_MANAGER

}
